/* ============================
   VOGAS — Store Logic
   Everything runs in the browser (localStorage).
   No backend/database — see README for what that means.
   ============================ */

const WHATSAPP_NUMBER = "923000000000"; // TODO: apna WhatsApp number yahan daalein (country code ke saath, + nahi)
const STORE_EMAIL = "orders@vogas.example.com"; // TODO: apna email yahan daalein

/* ---------------- Product data ---------------- */
const PRODUCTS = [
  { id: "bp-01", name: "Atlas Commuter Backpack", category: "Backpacks", price: 4290, colors: ["#2B2B2B","#6E0A0F"], material: "Water-resistant Canvas", size: "45 x 30 x 15 cm", capacity: "22L", rating: 4.6, reviews: 38, img: "https://placehold.co/700x700/6E0A0F/ffffff?text=Atlas+Backpack", img2: "https://placehold.co/700x700/4E0709/ffffff?text=Back+View", desc: "A slim commuter backpack built for laptops, notebooks and the daily grind. Padded straps, a hidden back pocket, and a structured base that keeps its shape." },
  { id: "bp-02", name: "Ridgeline Trek Backpack", category: "Backpacks", price: 5490, colors: ["#3B3B3B","#8C7A7A"], material: "Ripstop Nylon", size: "50 x 32 x 18 cm", capacity: "32L", rating: 4.8, reviews: 51, img: "https://placehold.co/700x700/4E0709/ffffff?text=Ridgeline", img2: "https://placehold.co/700x700/221616/ffffff?text=Back+View", desc: "Built for weekend hikes and overnight trips. Multiple compression straps, a rain cover, and a ventilated back panel." },
  { id: "bp-03", name: "Mini City Backpack", category: "Backpacks", price: 3190, colors: ["#6E0A0F","#221616"], material: "Vegan Leather", size: "28 x 22 x 11 cm", capacity: "12L", rating: 4.4, reviews: 22, img: "https://placehold.co/700x700/B4232C/ffffff?text=Mini+City", img2: "https://placehold.co/700x700/6E0A0F/ffffff?text=Back+View", desc: "A compact, everyday backpack that moves easily from desk to dinner. Soft structure with a single main compartment." },

  { id: "hb-01", name: "Camille Top-Handle Bag", category: "Handbags & Purses", price: 6290, colors: ["#6E0A0F","#221616","#ffffff"], material: "Genuine Leather", size: "26 x 18 x 10 cm", capacity: "6L", rating: 4.9, reviews: 64, img: "https://placehold.co/700x700/221616/ffffff?text=Camille+Bag", img2: "https://placehold.co/700x700/6E0A0F/ffffff?text=Side+View", desc: "A structured top-handle bag with a detachable strap, finished in full-grain leather that only gets better with age." },
  { id: "hb-02", name: "Noor Crossbody Purse", category: "Handbags & Purses", price: 3490, colors: ["#B4232C","#2B2B2B"], material: "Saffiano Leather", size: "20 x 14 x 6 cm", capacity: "3L", rating: 4.5, reviews: 29, img: "https://placehold.co/700x700/B4232C/ffffff?text=Noor+Crossbody", img2: "https://placehold.co/700x700/4E0709/ffffff?text=Side+View", desc: "Small enough for essentials only — cards, phone, keys — with an adjustable strap for day or evening wear." },
  { id: "hb-03", name: "Elle Tote Bag", category: "Handbags & Purses", price: 4990, colors: ["#221616","#ffffff"], material: "Canvas & Leather Trim", size: "38 x 30 x 14 cm", capacity: "18L", rating: 4.7, reviews: 40, img: "https://placehold.co/700x700/6E0A0F/ffffff?text=Elle+Tote", img2: "https://placehold.co/700x700/221616/ffffff?text=Side+View", desc: "An open-top tote roomy enough for a laptop, files and groceries alike, with reinforced leather handles." },

  { id: "tv-01", name: "Voyager Duffel 45L", category: "Travel & Duffel Bags", price: 5990, colors: ["#2B2B2B","#6E0A0F"], material: "Waxed Canvas", size: "55 x 28 x 26 cm", capacity: "45L", rating: 4.6, reviews: 33, img: "https://placehold.co/700x700/4E0709/ffffff?text=Voyager+Duffel", img2: "https://placehold.co/700x700/221616/ffffff?text=Side+View", desc: "A weekend-ready duffel with a separate shoe compartment and a trolley sleeve for travel days." },
  { id: "tv-02", name: "Transit Wheeled Duffel", category: "Travel & Duffel Bags", price: 8990, colors: ["#221616"], material: "Ballistic Nylon", size: "65 x 34 x 30 cm", capacity: "65L", rating: 4.8, reviews: 19, img: "https://placehold.co/700x700/221616/ffffff?text=Transit+Duffel", img2: "https://placehold.co/700x700/6E0A0F/ffffff?text=Side+View", desc: "Wheels for the terminal, straps for everywhere else. Fits carry-on sizing for most airlines." },

  { id: "lp-01", name: "Bexley Laptop Sleeve Bag", category: "Laptop Bags", price: 3890, colors: ["#221616","#6E0A0F"], material: "Full-grain Leather", size: "39 x 28 x 6 cm", capacity: "Fits up to 15.6\"", rating: 4.7, reviews: 27, img: "https://placehold.co/700x700/6E0A0F/ffffff?text=Bexley+Laptop", img2: "https://placehold.co/700x700/221616/ffffff?text=Inside+View", desc: "A padded sleeve with a document pocket and magnetic clasp — slim enough to slide into a bigger bag." },
  { id: "lp-02", name: "Warden Laptop Messenger", category: "Laptop Bags", price: 5290, colors: ["#2B2B2B","#8C7A7A"], material: "Canvas & Leather", size: "40 x 30 x 10 cm", capacity: "Fits up to 16\"", rating: 4.5, reviews: 21, img: "https://placehold.co/700x700/4E0709/ffffff?text=Warden+Messenger", img2: "https://placehold.co/700x700/221616/ffffff?text=Inside+View", desc: "A structured messenger with a quick-access front pocket, built for daily commuting between meetings." },

  { id: "sc-01", name: "Junior Explorer School Bag", category: "School Bags", price: 2690, colors: ["#6E0A0F","#2B2B2B"], material: "Polyester", size: "42 x 30 x 16 cm", capacity: "24L", rating: 4.4, reviews: 46, img: "https://placehold.co/700x700/B4232C/ffffff?text=Junior+Explorer", img2: "https://placehold.co/700x700/6E0A0F/ffffff?text=Back+View", desc: "Reinforced base and wide straps built for the school run — light enough to carry, tough enough for daily use." },
  { id: "sc-02", name: "Campus Everyday School Bag", category: "School Bags", price: 3190, colors: ["#221616","#B4232C"], material: "Ripstop Nylon", size: "44 x 32 x 17 cm", capacity: "26L", rating: 4.6, reviews: 35, img: "https://placehold.co/700x700/221616/ffffff?text=Campus+Bag", img2: "https://placehold.co/700x700/4E0709/ffffff?text=Back+View", desc: "A dedicated laptop sleeve, multiple compartments and a water bottle pocket for university days." },

  { id: "wl-01", name: "Denton Bifold Wallet", category: "Wallets & Accessories", price: 1690, colors: ["#221616","#6E0A0F"], material: "Genuine Leather", size: "11 x 9 cm", capacity: "8 card slots", rating: 4.8, reviews: 58, img: "https://placehold.co/700x700/4E0709/ffffff?text=Denton+Wallet", img2: "https://placehold.co/700x700/221616/ffffff?text=Inside+View", desc: "A slim bifold with room for cards and cash, finished in the same leather as our handbag line." },
  { id: "wl-02", name: "Reeve Card Holder", category: "Wallets & Accessories", price: 990, colors: ["#6E0A0F","#2B2B2B","#ffffff"], material: "Saffiano Leather", size: "10 x 7 cm", capacity: "4 card slots", rating: 4.5, reviews: 24, img: "https://placehold.co/700x700/B4232C/ffffff?text=Reeve+Cardholder", img2: "https://placehold.co/700x700/221616/ffffff?text=Inside+View", desc: "A pocket-sized card holder for anyone who's tired of carrying a full wallet." },
];

/* ---------------- Cart storage ---------------- */
function getCart() {
  try { return JSON.parse(localStorage.getItem("vogas_cart")) || []; }
  catch (e) { return []; }
}
function saveCart(cart) {
  localStorage.setItem("vogas_cart", JSON.stringify(cart));
  updateCartCount();
}
function addToCart(id, color, size, qty) {
  const cart = getCart();
  const existing = cart.find(i => i.id === id && i.color === color && i.size === size);
  if (existing) existing.qty += qty;
  else cart.push({ id, color, size: size || "-", qty });
  saveCart(cart);
}
function removeFromCart(index) {
  const cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
  renderCartPage();
}
function setQty(index, qty) {
  const cart = getCart();
  if (qty < 1) qty = 1;
  cart[index].qty = qty;
  saveCart(cart);
  renderCartPage();
}
function cartCount() {
  return getCart().reduce((sum, i) => sum + i.qty, 0);
}
function updateCartCount() {
  document.querySelectorAll(".cart-count").forEach(el => el.textContent = cartCount());
}

/* ---------------- Helpers ---------------- */
function formatPrice(n) { return "Rs " + n.toLocaleString("en-PK"); }
function findProduct(id) { return PRODUCTS.find(p => p.id === id); }
function starString(rating) {
  const full = Math.round(rating);
  return "★".repeat(full) + "☆".repeat(5 - full);
}
function showToast(msg) {
  let t = document.querySelector(".toast");
  if (!t) {
    t = document.createElement("div");
    t.className = "toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2200);
}

/* ---------------- Mobile nav ---------------- */
function initNavToggle() {
  const btn = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (btn && nav) btn.addEventListener("click", () => nav.classList.toggle("open"));
}

/* ---------------- Product card render ---------------- */
function productCard(p) {
  return `
    <a class="product-card" href="product.html?id=${p.id}">
      <div class="product-thumb"><img src="${p.img}" alt="${p.name}"></div>
      <h4>${p.name}</h4>
      <div class="product-meta">
        <span class="product-cat">${p.category}</span>
        <span class="price">${formatPrice(p.price)}</span>
      </div>
    </a>`;
}

/* ---------------- Home page ---------------- */
function renderFeatured() {
  const el = document.getElementById("featured-grid");
  if (!el) return;
  const featured = PRODUCTS.filter((p, i) => i % 3 === 0).slice(0, 8);
  el.innerHTML = featured.map(productCard).join("");
}

/* ---------------- Shop page ---------------- */
let activeFilters = { categories: new Set(), materials: new Set(), colors: new Set(), maxPrice: 10000 };

function initShopPage() {
  const grid = document.getElementById("shop-grid");
  if (!grid) return;

  const params = new URLSearchParams(location.search);
  const catParam = params.get("category");
  if (catParam) activeFilters.categories.add(catParam);

  document.querySelectorAll(".cat-filter").forEach(cb => {
    if (activeFilters.categories.has(cb.value)) cb.checked = true;
    cb.addEventListener("change", () => {
      cb.checked ? activeFilters.categories.add(cb.value) : activeFilters.categories.delete(cb.value);
      renderShopGrid();
    });
  });
  document.querySelectorAll(".mat-filter").forEach(cb => {
    cb.addEventListener("change", () => {
      cb.checked ? activeFilters.materials.add(cb.value) : activeFilters.materials.delete(cb.value);
      renderShopGrid();
    });
  });
  const priceSlider = document.getElementById("price-slider");
  if (priceSlider) {
    priceSlider.addEventListener("input", () => {
      activeFilters.maxPrice = Number(priceSlider.value);
      document.getElementById("price-slider-val").textContent = formatPrice(activeFilters.maxPrice);
      renderShopGrid();
    });
  }
  const sortSelect = document.getElementById("sort-select");
  if (sortSelect) sortSelect.addEventListener("change", renderShopGrid);

  renderShopGrid();
}

function renderShopGrid() {
  const grid = document.getElementById("shop-grid");
  let list = PRODUCTS.filter(p => {
    if (activeFilters.categories.size && !activeFilters.categories.has(p.category)) return false;
    if (activeFilters.materials.size && !activeFilters.materials.has(p.material)) return false;
    if (p.price > activeFilters.maxPrice) return false;
    return true;
  });
  const sort = document.getElementById("sort-select")?.value;
  if (sort === "price-asc") list.sort((a, b) => a.price - b.price);
  if (sort === "price-desc") list.sort((a, b) => b.price - a.price);
  if (sort === "rating") list.sort((a, b) => b.rating - a.rating);

  document.getElementById("result-count").textContent = list.length;
  grid.innerHTML = list.length ? list.map(productCard).join("")
    : `<p style="grid-column:1/-1;color:var(--muted)">Is filter ke sath koi product nahi mila.</p>`;
}

/* ---------------- Product detail page ---------------- */
let selectedColor = null, selectedSize = null;

function initProductPage() {
  const wrap = document.getElementById("pd-wrap");
  if (!wrap) return;
  const id = new URLSearchParams(location.search).get("id");
  const p = findProduct(id) || PRODUCTS[0];
  selectedColor = p.colors[0];
  selectedSize = "One Size";

  document.getElementById("pd-crumb-name").textContent = p.name;
  document.getElementById("pd-main-img").src = p.img;
  document.getElementById("pd-thumbs").innerHTML = [p.img, p.img2].map((src, i) =>
    `<img src="${src}" class="${i === 0 ? "active" : ""}" onclick="switchImg(this,'${src}')">`
  ).join("");
  document.getElementById("pd-cat").textContent = p.category;
  document.getElementById("pd-title").textContent = p.name;
  document.getElementById("pd-price").textContent = formatPrice(p.price);
  document.getElementById("pd-rating").textContent = `${starString(p.rating)}  ${p.rating} (${p.reviews} reviews)`;
  document.getElementById("pd-desc").textContent = p.desc;

  document.getElementById("pd-colors").innerHTML = p.colors.map((c, i) =>
    `<span class="opt-swatch ${i === 0 ? "selected" : ""}" style="background:${c}" onclick="selectColor(this,'${c}')"></span>`
  ).join("");
  document.getElementById("pd-sizes").innerHTML = ["Small", "Medium", "Large"].map((s, i) =>
    `<span class="opt-size ${s === "Medium" ? "selected" : ""}" onclick="selectSize(this,'${s}')">${s}</span>`
  ).join("");
  selectedSize = "Medium";

  document.getElementById("specs-material").textContent = p.material;
  document.getElementById("specs-size").textContent = p.size;
  document.getElementById("specs-capacity").textContent = p.capacity;

  document.getElementById("pd-add-cart").onclick = () => {
    const qty = Number(document.getElementById("pd-qty").value) || 1;
    addToCart(p.id, selectedColor, selectedSize, qty);
    showToast(`${p.name} cart mein add ho gaya`);
  };
  document.getElementById("pd-buy-now").onclick = () => {
    const qty = Number(document.getElementById("pd-qty").value) || 1;
    addToCart(p.id, selectedColor, selectedSize, qty);
    location.href = "cart.html";
  };

  renderRelated(p);
}

function switchImg(el, src) {
  document.getElementById("pd-main-img").src = src;
  document.querySelectorAll(".pd-gallery-thumbs img").forEach(i => i.classList.remove("active"));
  el.classList.add("active");
}
function selectColor(el, c) {
  selectedColor = c;
  document.querySelectorAll(".opt-swatch").forEach(s => s.classList.remove("selected"));
  el.classList.add("selected");
}
function selectSize(el, s) {
  selectedSize = s;
  document.querySelectorAll(".opt-size").forEach(o => o.classList.remove("selected"));
  el.classList.add("selected");
}
function changeQty(delta) {
  const input = document.getElementById("pd-qty");
  let v = Number(input.value) + delta;
  if (v < 1) v = 1;
  input.value = v;
}
function renderRelated(p) {
  const el = document.getElementById("related-grid");
  if (!el) return;
  const related = PRODUCTS.filter(x => x.category === p.category && x.id !== p.id).slice(0, 4);
  el.innerHTML = related.map(productCard).join("");
}

/* ---------------- Cart page ---------------- */
function renderCartPage() {
  const body = document.getElementById("cart-body");
  if (!body) return;
  const cart = getCart();

  if (!cart.length) {
    document.getElementById("cart-full").style.display = "none";
    document.getElementById("cart-empty").style.display = "block";
    return;
  }
  document.getElementById("cart-full").style.display = "grid";
  document.getElementById("cart-empty").style.display = "none";

  let subtotal = 0;
  body.innerHTML = cart.map((item, idx) => {
    const p = findProduct(item.id);
    if (!p) return "";
    const lineTotal = p.price * item.qty;
    subtotal += lineTotal;
    return `
      <tr>
        <td>
          <div class="cart-item-info">
            <img src="${p.img}" alt="${p.name}">
            <div>
              <div style="font-weight:600;font-size:14px">${p.name}</div>
              <div class="meta">Color: <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${item.color};vertical-align:middle"></span> &nbsp; Size: ${item.size}</div>
              <div class="remove-link" onclick="removeFromCart(${idx})">Remove</div>
            </div>
          </div>
        </td>
        <td>${formatPrice(p.price)}</td>
        <td>
          <div class="qty-box">
            <button onclick="setQty(${idx}, ${item.qty - 1})">−</button>
            <input type="text" value="${item.qty}" readonly>
            <button onclick="setQty(${idx}, ${item.qty + 1})">+</button>
          </div>
        </td>
        <td style="font-weight:600">${formatPrice(lineTotal)}</td>
      </tr>`;
  }).join("");

  const shipping = subtotal > 5000 || subtotal === 0 ? 0 : 200;
  document.getElementById("sum-subtotal").textContent = formatPrice(subtotal);
  document.getElementById("sum-shipping").textContent = shipping === 0 ? "Free" : formatPrice(shipping);
  document.getElementById("sum-total").textContent = formatPrice(subtotal + shipping);

  document.getElementById("checkout-btn").onclick = () => placeOrder(subtotal + shipping);
}

function placeOrder(total) {
  const name = document.getElementById("ship-name")?.value;
  const phone = document.getElementById("ship-phone")?.value;
  const address = document.getElementById("ship-address")?.value;
  const method = document.querySelector('input[name="pay-method"]:checked')?.value || "COD";

  if (!name || !phone || !address) {
    showToast("Pehle shipping details bhar dein");
    return;
  }

  const cart = getCart();
  let lines = cart.map(item => {
    const p = findProduct(item.id);
    return `- ${p.name} (${item.size}) x${item.qty} = ${formatPrice(p.price * item.qty)}`;
  }).join("%0A");

  const message = `Naya Order — VOGAS%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AAddress: ${encodeURIComponent(address)}%0APayment: ${method}%0A%0AItems:%0A${lines}%0A%0ATotal: ${formatPrice(total)}`;

  const choice = document.getElementById("order-via").value;
  if (choice === "email") {
    location.href = `mailto:${STORE_EMAIL}?subject=Naya Order - VOGAS&body=${message}`;
  } else {
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank");
  }
}

/* ---------------- FAQ accordion ---------------- */
function initFaq() {
  document.querySelectorAll(".faq-item").forEach(item => {
    item.querySelector(".faq-q").addEventListener("click", () => {
      item.classList.toggle("open");
    });
  });
}

/* ---------------- Contact form ---------------- */
function initContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return;
  form.addEventListener("submit", e => {
    e.preventDefault();
    const name = document.getElementById("c-name").value;
    const msg = document.getElementById("c-message").value;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hi VOGAS, mera naam ${name} hai.\n\n${msg}`)}`, "_blank");
  });
}

/* ---------------- Init on load ---------------- */
document.addEventListener("DOMContentLoaded", () => {
  updateCartCount();
  initNavToggle();
  renderFeatured();
  initShopPage();
  initProductPage();
  renderCartPage();
  initFaq();
  initContactForm();
});
